import { useCallback, useEffect, useMemo, useRef } from 'react';
import { TYPE_ICON_KEYS } from '../../lib/typeIcons';
import { highlight } from './highlight';

/**
 * React port of legacy's `window.FUTA_SEARCH` (app.js ~547–648).
 *
 * Legacy builds this as a plain mutable object with a closed-over `index`
 * array, populated imperatively over the session by `register()` calls
 * from `loadSavedWaypoints`, `loadSavedSegments`/`drawSavedSegment`,
 * `loadKML`, and — for OSM results — `selectResult()`/`bindRouteInput`'s
 * OSM debounce. None of that data layer existed until this slice: Slice 4
 * explicitly deferred `drawSavedSegment`'s `FUTA_SEARCH.register(...)`
 * call, and Slice 5/6 both flagged the same for KML/waypoints, all
 * pointing at "Slice 7 (search)". This hook is where that gets picked up.
 *
 * Deviation, flagged: legacy never *removes* stale entries from three of
 * its four registration sources — once a waypoint/segment/KML point is
 * registered it stays in `FUTA_SEARCH.index` for the rest of the page
 * session, even if deleted server-side, with exactly one documented
 * exception (app.js ~1826–1832, a waypoints-only refresh inside the admin
 * flow that isn't built yet — Slice 11). Since this port re-fetches
 * waypoints/segments via `refetch()` after every save (Slice 4/5's save
 * flows), keeping stale entries around would leave deleted/renamed places
 * searchable forever within a session. This hook instead re-syncs the
 * "static" (waypoint/segment/kml) portion of the index on every
 * `waypoints`/`segments`/`kmlAnnotations` change, generalizing legacy's
 * one documented refresh case to all three static sources rather than
 * guessing which one specifically was meant. OSM entries registered via
 * `register()` (ephemeral, matches legacy exactly) are left untouched by
 * this resync — same as legacy, they persist for the session once found.
 *
 * `register`/`query`/`resolve`/`highlight`/`icon` all match legacy's
 * FUTA_SEARCH methods 1:1 (same dedup keys, same scoring weights).
 */

const TYPE_ICONS = { waypoint: 'geo-alt-fill', segment: 'route', osm: 'globe', kml: 'folder' };

function norm(s) {
  return (s || '').toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
}

function score(entry, q) {
  if (!q) return 0;
  const nq = norm(q);
  const nn = norm(entry.name);
  const nd = norm(entry.desc || '');
  const words = nq.split(/\s+/);

  let s = 0;
  if (nn === nq) s += 100;
  if (nn.startsWith(nq)) s += 60;
  if (nn.includes(nq)) s += 40;
  words.forEach((w) => {
    if (nn.includes(w)) s += 20;
    if (nd.includes(w)) s += 8;
  });

  if (entry.source === 'waypoint') s += 15;
  if (entry.source === 'business') s += 15; // an Online Store is as much a "real named place" match as a waypoint
  if (entry.source === 'segment') s += 10;
  return s;
}

function icon(entry) {
  return TYPE_ICON_KEYS[entry.subtype] || TYPE_ICONS[entry.subtype] || TYPE_ICONS[entry.type] || 'geo-alt-fill';
}

export function useSearchIndex({ waypoints, segments, kmlAnnotations }) {
  // Mutable, not React state — legacy's FUTA_SEARCH.index is queried
  // synchronously from event handlers (keystrokes, clicks), never drives
  // a render on its own. Matches the imperative-Leaflet-ref pattern this
  // project already uses elsewhere (see CLAUDE.md's "raw Leaflet" rule).
  const indexRef = useRef([]);
  const idSetRef = useRef(new Set());
  const nameCoordSetRef = useRef(new Set());

  const register = useCallback((entry) => {
    const idKey = entry.id || '';
    const normName = (entry.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const ncKey = normName + '|' + (entry.lat || 0).toFixed(5) + '|' + (entry.lng || 0).toFixed(5);

    if (idKey && idSetRef.current.has(idKey)) return;
    if (nameCoordSetRef.current.has(ncKey)) return;
    if (
      normName &&
      !entry.lat &&
      !entry.lng &&
      indexRef.current.some((e) => (e.name || '').toLowerCase().replace(/[^a-z0-9]/g, '') === normName)
    )
      return;

    if (idKey) idSetRef.current.add(idKey);
    nameCoordSetRef.current.add(ncKey);
    indexRef.current.push(entry);
  }, []);

  // ── Resync the static (waypoint/segment/kml) portion on data change ──
  useEffect(() => {
    indexRef.current = indexRef.current.filter(
      (e) => e.source !== 'waypoint' && e.source !== 'business' && e.source !== 'segment' && e.source !== 'kml'
    );
    idSetRef.current.clear();
    nameCoordSetRef.current.clear();
    indexRef.current.forEach((e) => {
      if (e.id) idSetRef.current.add(e.id);
      const normName = (e.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      nameCoordSetRef.current.add(normName + '|' + (e.lat || 0).toFixed(5) + '|' + (e.lng || 0).toFixed(5));
    });

    // waypoint entries — mirrors app.js ~3446's register() shape.
    // People (supabase/people_entries.sql) and Channel (supabase/
    // channel_entries.sql) entries have no lat/lng and aren't a
    // navigable destination, so they're left out of location search/
    // quick-chips entirely — they're only reachable via the Explore
    // panel's People/Channels pills.
    //
    // Business entries (supabase/business_entries.sql) are the one
    // exception to that rule, by explicit request: also no lat/lng, but
    // DOES need to be findable by typing its name in the search bar
    // (that's the whole point of an Online Store listing someone can
    // search for) — just not "navigable" in the fly-to-a-pin sense. See
    // useSelectResult.js's own comment for how selecting a coordinate-
    // less business result is handled differently from every other
    // search source once picked.
    //
    // Paid Online Stores (a business that came from an approved promotion,
    // marked by `promoPaidAt`, supabase/promotions_dedupe_ranking.sql) are
    // left out too: they're ads and belong in Explore only. Businesses an
    // admin adds by hand ("+ Add Business") stay searchable.
    (waypoints || []).forEach((wp) => {
      if (wp.isPerson || wp.isChannel) return;
      if (wp.isBusiness && wp.promoPaidAt) return;
      register({
        id: wp.id,
        lat: wp.lat,
        lng: wp.lng,
        name: wp.name,
        desc: wp.description || '',
        type: wp.type,
        subtype: wp.isBusiness ? 'shop' : wp.type, // generic storefront icon — a Business row has no `type` of its own
        imageUrls: wp.imageUrls || [],
        avgRating: wp.avgRating,
        reviewCount: wp.reviewCount,
        source: wp.isBusiness ? 'business' : 'waypoint',
        isBusiness: !!wp.isBusiness,
        businessLink: wp.businessLink || '',
        businessPlatform: wp.businessPlatform || '',
      });
    });

    // segment entries — mirrors drawSavedSegment's register() (app.js
    // ~2579–2588): midpoint of the route's points, name/desc/category.
    (segments || []).forEach((seg) => {
      if (!seg.points || seg.points.length === 0) return;
      const mid = seg.points[Math.floor(seg.points.length / 2)];
      register({
        id: seg.id,
        lat: mid.lat,
        lng: mid.lng,
        name: seg.name,
        desc: seg.description || seg.category || '',
        type: 'segment',
        subtype: 'segment',
        source: 'segment',
      });
    });

    // KML annotation entries — mirrors app.js ~3537.
    (kmlAnnotations || []).forEach((a) => {
      register({
        id: a.id,
        lat: a.lat,
        lng: a.lng,
        name: a.name,
        desc: '',
        type: 'waypoint',
        subtype: 'kml',
        source: 'kml',
      });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [waypoints, segments, kmlAnnotations]);

  const query = useCallback((q, limit = 6) => {
    if (!q || q.trim().length < 1) return [];
    return indexRef.current
      .map((e) => ({ ...e, _score: score(e, q) }))
      .filter((e) => e._score > 0)
      .sort((a, b) => b._score - a._score)
      .slice(0, limit);
  }, []);

  const resolve = useCallback(
    (input) => {
      if (!input) return null;
      const coordMatch = input.match(/(-?\d+\.?\d*)[,\s]+(-?\d+\.?\d*)/);
      if (coordMatch) {
        return { lat: parseFloat(coordMatch[1]), lng: parseFloat(coordMatch[2]), name: input, type: 'coord' };
      }
      const results = query(input, 1);
      return results.length ? results[0] : null;
    },
    [query]
  );

  return useMemo(
    () => ({ register, query, resolve, highlight, icon, indexRef }),
    [register, query, resolve]
  );
}

import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, X } from 'lucide-react';
import { fetchNominatim } from './nominatimSearch';
import { useSelectResult } from './useSelectResult';
import { findDuplicate } from '../osm-annotations/osmAnnotationUtils';
import SearchDropdownList from './SearchDropdownList';
import styles from './MobileSearchOverlay.module.css';
import { readPersistentState, writePersistentState } from '../../lib/persistentState';
import { track } from '../../lib/analytics';

/**
 * Ported from legacy's dynamically-built `#mobSearchOverlay` (app.js
 * ~5808–5958) — a comment-flagged fix: "mobSearchTrig was captured but
 * never wired — this fixes it." Full-screen overlay opened by
 * MobileSearchBar, giving mobile the same live local+OSM suggestions as
 * desktop.
 *
 * Reuses SearchDropdownList/SearchResultItem (built for the desktop
 * dropdown) rather than re-implementing legacy's near-identical but
 * slightly-larger `.mob-ov-item` row style, and passes `showBadge={false}`
 * to match one real difference: legacy's mobile rows never render the
 * type badge desktop's `.sd-item` does. The row padding/font-size here
 * matches the desktop dropdown rather than legacy's separate (marginally
 * larger) mobile numbers — a minor, flagged simplification, not a
 * behavioral one.
 *
 * v2 redesign: restyled to v2 light tokens
 * per Figma node 4:249 ("Search Results Redesign") — see tokens-v2.css
 * for how this frame's colors/font map onto existing tokens. Structure,
 * props, handlers, and search behavior untouched; the show/close
 * mechanism (`open`/`active` class) is unchanged too, just animated (see
 * .module.css). Paired in the same session with DesktopSearchBar's
 * `.dropdown`, since both surfaces render this exact list content via
 * the shared SearchDropdownList/SearchResultItem components.
 *
 * Faithfully NOT ported: unlike the desktop bar's Enter-with-no-selection
 * behavior (`deskDoSearch`, which falls back to a full OSM search),
 * legacy's mobile overlay Enter handler (~5939–5948) only tries
 * `FUTA_SEARCH.resolve()` and does nothing if that comes up empty — no OSM
 * fallback. Reproduced exactly as-is.
 */
export default function MobileSearchOverlay({ open, map, searchIndex, onSelect, onClose }) {
  const [query, setQuery] = useState(() => readPersistentState('mobile-search-query', ''));
  const [osmResults, setOsmResults] = useState(null);
  const [loadingOsm, setLoadingOsm] = useState(false);
  const inputRef = useRef(null);
  const debounceRef = useRef(null);
  const lastOsmQRef = useRef('');
  // For Insights' search tracking: whether this query was typed since the
  // overlay opened (a restored one isn't a new search), which query the
  // current OSM results belong to, and which query's OSM fetch failed.
  const typedRef = useRef(false);
  const osmForRef = useRef('');
  const osmFailedForRef = useRef('');

  const { selectResult } = useSelectResult({ map, searchIndex, onSelect });
  const localResults = query.trim() ? searchIndex.query(query, 6) : [];

  useEffect(() => {
    if (open) {
      typedRef.current = false;
      // Results were cleared on close, so a retyped query must fetch again.
      lastOsmQRef.current = '';
      osmForRef.current = '';
      osmFailedForRef.current = '';
      setQuery(readPersistentState('mobile-search-query', ''));
      const t = setTimeout(() => inputRef.current?.focus(), 80);
      return () => clearTimeout(t);
    }
    setQuery('');
    setOsmResults(null);
  }, [open]);

  useEffect(() => {
    if (open) writePersistentState('mobile-search-query', query);
  }, [open, query]);

  // OSM results only count for the query they were fetched for.
  function resultCount() {
    const osm = osmForRef.current === query && osmResults ? osmResults.length : 0;
    return localResults.length + osm;
  }

  function handleSelect(entry) {
    if (query.trim()) track('search_query', { query: query.trim(), result_count: resultCount() });
    selectResult(entry);
    onClose();
  }

  // Leaving with a query that found nothing is the "searched but found
  // nothing" signal. Only on close, not while typing, so half-typed words
  // aren't counted; and only for a query typed this time whose OSM search
  // actually finished (not still loading, not failed).
  function handleClose() {
    const q = query.trim();
    const osmSettled = q.length < 3 || (osmForRef.current === query && !loadingOsm);
    if (q && typedRef.current && osmSettled && osmFailedForRef.current !== query && resultCount() === 0) {
      track('search_query', { query: q, result_count: 0 });
    }
    onClose();
  }

  function handleInputChange(e) {
    const q = e.target.value;
    typedRef.current = true;
    setQuery(q);
    if (!q.trim()) {
      setOsmResults(null);
      return;
    }
    clearTimeout(debounceRef.current);
    if (q.trim().length >= 3 && q !== lastOsmQRef.current) {
      setLoadingOsm(true);
      debounceRef.current = setTimeout(async () => {
        lastOsmQRef.current = q;
        try {
          const raw = await fetchNominatim(q, { limit: 4 });
          const filtered = raw.filter((r) => !findDuplicate(r.lat, r.lng, r.name, searchIndex.indexRef.current));
          osmForRef.current = q;
          setOsmResults(filtered.length ? filtered : null);
        } catch {
          // matches legacy's silent .catch(() => {})
          osmFailedForRef.current = q;
        } finally {
          setLoadingOsm(false);
        }
      }, 420);
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') {
      const q = query.trim();
      if (!q) return;
      const local = searchIndex.resolve(q);
      if (local) handleSelect(local);
    } else if (e.key === 'Escape') {
      handleClose();
    }
  }

  function handleClear() {
    setQuery('');
    setOsmResults(null);
    inputRef.current?.focus();
  }

  return (
    <div className={`${styles.overlay} ${open ? styles.active : ''}`}>
      <div className={styles.ovBar}>
        <button className={styles.back} onClick={handleClose} aria-label="Back" type="button">
          <ArrowLeft size={20} />
        </button>
        <input
          ref={inputRef}
          className={styles.input}
          placeholder="Search FUTA campus…"
          autoComplete="off"
          spellCheck="false"
          value={query}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
        />
        {query && (
          <button className={styles.clear} onClick={handleClear} aria-label="Clear" type="button">
            <X size={16} />
          </button>
        )}
      </div>
      <div className={styles.results}>
        <SearchDropdownList
          localResults={localResults}
          osmResults={osmResults}
          query={query}
          loading={loadingOsm}
          icon={searchIndex.icon}
          highlight={searchIndex.highlight}
          onSelect={handleSelect}
          showBadge={false}
        />
      </div>
    </div>
  );
}

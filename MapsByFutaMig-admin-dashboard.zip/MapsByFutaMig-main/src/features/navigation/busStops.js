import { haversine } from '../../lib/geoUtils.js';
import { VEHICLE_SPEED_KMH } from './gpsConstants.js';

// "On a shuttle? Get off at ..." for users riding the campus shuttle. Only
// shuttle stops recorded on the map (waypoints of type 'bus_stop') count;
// with none near the destination, riding or not, navigation carries on
// as normal.

const RIDING_MPS = VEHICLE_SPEED_KMH / 3.6;
// Walking pace. Standing still doesn't count: a shuttle waiting at a stop
// with the rider still on board reads as ~0.
const WALKING_MIN_MPS = 0.5;
const WALKING_MAX_MPS = 2;
const RIDE_TICKS = 2; // fast fixes in a row before we call it a ride
const WALK_TICKS = 4; // walking-pace fixes in a row before we call the ride over
// ...over at least this long, so a vehicle crawling through traffic or
// over a speed bump for a few seconds isn't taken for walking.
const WALK_MIN_MS = 12000;
// Speed worked out from positions only from fixes this accurate: GPS
// jitter between rougher fixes can look like a vehicle.
export const DERIVED_SPEED_MAX_ACCURACY_M = 20;
export const MAX_STOP_TO_DEST_M = 500;
export const ANNOUNCE_AHEAD_M = 250;
export const GET_OFF_NOW_M = 40;

/**
 * The OSRM profile for a travel mode at this moment, from speed. Vehicles
 * get car routes: bike routes may walk a bike down footpaths or against
 * one-ways, which a keke can't do.
 *  - Walk: walking; car routes while riding, walking again once off.
 *  - Keke / Car: car routes; walking once they get off (the last stretch
 *    may be a path a vehicle can't take), car again if they ride again.
 *  - Shuttle: car routes until they get off, then walking for good.
 *  - Bike (bicycle, okada): bike routes throughout.
 */
export function routeProfile(travel, riding, gotOff) {
  if (travel === 'bike') return 'cycling-regular';
  if (travel === 'walk') return riding ? 'driving-car' : 'foot-walking';
  if (travel === 'shuttle') return gotOff ? 'foot-walking' : 'driving-car';
  return gotOff && !riding ? 'foot-walking' : 'driving-car';
}

/**
 * Speed (m/s) between two fixes, for phones that don't report one.
 * Null when the fixes are too close together or too far apart in time to
 * tell.
 */
export function speedBetween(prev, next) {
  if (!prev || !next) return null;
  if (!(prev.accuracy <= DERIVED_SPEED_MAX_ACCURACY_M && next.accuracy <= DERIVED_SPEED_MAX_ACCURACY_M)) return null;
  const secs = (next.at - prev.at) / 1000;
  if (!(secs >= 1 && secs <= 30)) return null;
  return haversine(prev.lat, prev.lng, next.lat, next.lng) / secs;
}

/**
 * Feed it each fix's GPS speed (m/s, may be null) and time (ms). `update`
 * returns { riding, alighted } — `alighted` is true once, on the fix where
 * a ride ends. `riding` starts a restored trip mid-ride.
 */
export function createRideDetector({ riding: startRiding = false } = {}) {
  let riding = startRiding;
  let fast = 0;
  let slow = 0;
  let slowSince = 0;
  return {
    get riding() {
      return riding;
    },
    update(speed, at) {
      if (!Number.isFinite(speed)) return { riding, alighted: false };
      fast = speed >= RIDING_MPS ? fast + 1 : 0;
      // Stopped fixes neither end a ride nor break a run of walking ones.
      if (speed >= WALKING_MIN_MPS) {
        if (speed > WALKING_MAX_MPS) slow = 0;
        else if (slow++ === 0) slowSince = at;
      }
      if (!riding && fast >= RIDE_TICKS) riding = true;
      else if (riding && slow >= WALK_TICKS && at - slowSince >= WALK_MIN_MS) {
        riding = false;
        return { riding, alighted: true };
      }
      return { riding, alighted: false };
    },
  };
}

const dist = (a, b) => haversine(Number(a.lat), Number(a.lng), Number(b.lat), Number(b.lng));

/**
 * The shuttle stop to get off at: of the stops recorded on the map, the
 * one nearest the destination — if it's within MAX_STOP_TO_DEST_M of it
 * and not one the rider has already passed (no further from the
 * destination than they are, give or take GET_OFF_NOW_M). Straight-line
 * distances: the shuttle's road and the walking route often differ.
 * Returns { place, toUser } (metres from `user`) or null.
 */
export function alightStop(dest, user, places) {
  let best = null;
  let bestToDest = Infinity;
  const userToDest = dist(user, dest);
  for (const p of places || []) {
    if (p.type !== 'bus_stop' || !p.name || !Number.isFinite(Number(p.lat)) || !Number.isFinite(Number(p.lng))) continue;
    const toDest = dist(p, dest);
    if (toDest > MAX_STOP_TO_DEST_M || toDest > userToDest + GET_OFF_NOW_M) continue;
    if (toDest < bestToDest) {
      best = p;
      bestToDest = toDest;
    }
  }
  return best ? { place: best, toUser: dist(best, user) } : null;
}

/**
 * What to tell a rider `metresToStop` from their stop, or null when it's
 * still too far to mention. `stage` lets the caller speak each prompt
 * once. Speed can't tell a campus shuttle from a keke or car, so the
 * wording says who it's for and everyone else can ignore it.
 */
export function alightPrompt(metresToStop, name) {
  if (metresToStop > ANNOUNCE_AHEAD_M) return null;
  return metresToStop <= GET_OFF_NOW_M
    ? { stage: 'now', instruction: `On a shuttle? Get off here at ${name}`, spoken: `If you're on a shuttle, get off here, at ${name}.` }
    : { stage: 'ahead', instruction: `On a shuttle? Get off at ${name}`, spoken: `If you're on a shuttle, get ready to get off at ${name}.` };
}

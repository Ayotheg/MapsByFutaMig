import { useCallback, useEffect, useRef, useState } from 'react';
import { supabase, getPlaceImageUrl } from '../../lib/supabase';
import { isTimeoutError } from '../../lib/networkTimeout';
import { fetchAllRows } from '../../lib/fetchAllRows';
import { cacheGet, cacheSet } from '../../lib/localCache';

const CACHE_KEY = 'segments';

/**
 * Loads saved segments (+ their photos, + their linked waypoints) from
 * Supabase, shaped for SegmentsLayer/DetailModal. Mirrors legacy
 * `loadSavedSegments` (app.js ~2771–2795), minus:
 *   - the sessionStorage read-cache (Part B #1 in legacy) — same call as
 *     useWaypoints.js: Supabase's free-tier limits don't create the read
 *     pressure that cache was built to solve.
 *   - segColorIdx's module-level running counter for polyline colour —
 *     that's a rendering concern, handled in SegmentsLayer.jsx instead.
 *
 * ── SCHEMA ──────────────────────────────────────────────────────────────
 *   1. There is no `points` jsonb column on `segments`. The GPS track is
 *      its own table, `segment_points (segment_id, seq, lat, lng,
 *      accuracy, speed, recorded_at)`, ordered by `seq`.
 *   2. The distance/duration columns are `distance_m` (metres) and
 *      `duration_ms` (milliseconds). Shaped output below exposes them as
 *      `distance`/`duration` for SegmentsLayer.jsx/DetailModal.jsx.
 *
 * `segment_images (segment_id, storage_path, position)` — Slice 4's
 * assumption already matched this doc exactly, no change needed there.
 *
 * A segment's *waypoints* (shown in the detail modal) are still NOT read
 * from an embedded array — `waypoints.segment_id` is a real FK per this
 * same doc, so `waypoints WHERE segment_id = seg.id` (Slice 4's deviation)
 * stands, now confirmed rather than assumed.
 *
 * ── Still unconfirmed, flagging for whoever does the live-data pass ──────
 * RLS is enabled on all five tables per the migration doc's Step 0, but
 * CLAUDE.md's Session Context only confirms SELECT policies were actually
 * added (in the Supabase dashboard) for `waypoints`/`waypoint_images`.
 * `segments`/`segment_points`/`segment_images` aren't mentioned as having
 * policies added — if they don't have one yet, these queries won't throw,
 * they'll just silently return empty arrays (RLS-with-no-policy blocks
 * rows rather than erroring), which reads as "no segments saved yet"
 * rather than "misconfigured". Worth a direct check before trusting an
 * empty segments list. Slice 5's save-flow INSERT has the same exposure in
 * the other direction — see segmentSave.js.
 */
export function useSegments() {
  const [segments, setSegments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isOffline, setIsOffline] = useState(false);
  const [cachedAt, setCachedAt] = useState(null);

  // Same guard as useWaypoints: an older load finishing late (a retry
  // overlapping the 'online' refetch) mustn't overwrite a newer one.
  const loadIdRef = useRef(0);

  const load = useCallback(async () => {
    const loadId = ++loadIdRef.current;
    setLoading(true);
    setError(null);

    // Same fast-path as useWaypoints: don't wait on a request that has no
    // chance of succeeding if the browser already knows there's no network.
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      const cached = cacheGet(CACHE_KEY);
      if (cached) {
        setSegments(cached.value);
        setIsOffline(true);
        setCachedAt(cached.savedAt);
      } else {
        // Keep whatever is already on screen.
        setError(new Error('offline'));
      }
      setLoading(false);
      return;
    }

    // Every query is paged (lib/fetchAllRows.js) — `segment_points` in
    // particular easily exceeds PostgREST's silent 1000-row response cap,
    // which would truncate routes mid-line.
    let segRows, segErr, imgRows, imgErr, wpRows, wpErr, ptRows, ptErr;
    [
      { data: segRows, error: segErr },
      { data: imgRows, error: imgErr },
      { data: wpRows, error: wpErr },
      { data: ptRows, error: ptErr },
    ] = await Promise.all([
      fetchAllRows(() =>
        supabase
          .from('segments')
          .select('id, name, description, category, distance_m, duration_ms')
          .order('id', { ascending: true })
      ),
      fetchAllRows(() =>
        supabase
          .from('segment_images')
          .select('segment_id, storage_path, position')
          .order('segment_id', { ascending: true })
          .order('position', { ascending: true })
          .order('id', { ascending: true })
      ),
      fetchAllRows(() =>
        supabase
          .from('waypoints')
          .select('id, name, description, lat, lng, segment_id')
          .not('segment_id', 'is', null)
          .order('id', { ascending: true })
      ),
      fetchAllRows(() =>
        supabase
          .from('segment_points')
          .select('segment_id, seq, lat, lng')
          .order('segment_id', { ascending: true })
          .order('seq', { ascending: true })
      ),
    ]);

    if (loadId !== loadIdRef.current) return; // a newer load() superseded this one

    if (segErr || imgErr || wpErr || ptErr) {
      const timedOut = [segErr, imgErr, wpErr, ptErr].some(isTimeoutError);
      const cached = cacheGet(CACHE_KEY);
      if (cached) {
        setSegments(cached.value);
        setIsOffline(true);
        setCachedAt(cached.savedAt);
        setError(null);
        console.warn(
          `[segments] Live load failed${timedOut ? ' (timed out)' : ''}, showing cached data from ${new Date(cached.savedAt).toLocaleString()}.`
        );
      } else {
        setError(segErr || imgErr || wpErr || ptErr);
      }
      setLoading(false);
      return;
    }

    setIsOffline(false);

    const pointsBySegment = {};
    for (const row of ptRows || []) {
      (pointsBySegment[row.segment_id] ??= []).push({
        lat: Number(row.lat),
        lng: Number(row.lng),
      });
    }

    const imagesBySegment = {};
    for (const row of imgRows || []) {
      const url = getPlaceImageUrl(row.storage_path);
      if (!url) continue;
      (imagesBySegment[row.segment_id] ??= []).push(url);
    }

    const waypointsBySegment = {};
    for (const wp of wpRows || []) {
      (waypointsBySegment[wp.segment_id] ??= []).push({
        id: wp.id,
        name: wp.name,
        // numeric columns come back as strings over PostgREST — coerce
        // before doing math or handing to Leaflet (same rule useWaypoints
        // follows).
        lat: Number(wp.lat),
        lng: Number(wp.lng),
        desc: wp.description || '',
      });
    }

    const shaped = (segRows || []).map((seg) => ({
      id: seg.id,
      name: seg.name,
      description: seg.description || '',
      category: seg.category,
      // Sourced from segment_points now, not a jsonb column — see the
      // schema note above.
      points: pointsBySegment[seg.id] || [],
      distance: Number(seg.distance_m) || 0,
      duration: Number(seg.duration_ms) || 0,
      imageUrls: imagesBySegment[seg.id] || [],
      waypoints: waypointsBySegment[seg.id] || [],
    }));

    setSegments(shaped);
    setCachedAt(null);
    setLoading(false);
    cacheSet(CACHE_KEY, shaped);
  }, []);

  // Every caller (first load, 'online', Retry) goes through this, so a
  // throw never leaves `loading` stuck on.
  const safeLoad = useCallback(
    () =>
      load().catch((e) => {
        setError(e);
        setLoading(false);
      }),
    [load]
  );

  useEffect(() => {
    safeLoad();
    // Same auto-recover behavior as useWaypoints.js — refetch live data
    // the moment the browser regains connectivity, no manual refresh
    // needed.
    window.addEventListener('online', safeLoad);
    return () => window.removeEventListener('online', safeLoad);
  }, [safeLoad]);

  // Slice 5: exposed so the save flow can refresh the list after inserting
  // a new segment — the equivalent of legacy's `reloadAllWaypoints()` +
  // `drawSavedSegment(newSeg)` pair, just re-fetching instead of hand-
  // splicing the new row into local state.
  return { segments, loading, error, isOffline, cachedAt, refetch: safeLoad };
}
import './landing/landing.css'
import { useSeo } from '../lib/useSeo'
import Nav from './landing/Nav'
import Hero from './landing/Hero'
import TrustBar from './landing/TrustBar'
// import LaunchCountdown from './landing/LaunchCountdown'
import CampusTransformSection from './landing/CampusTransformSection'
import ProductFeatures from './landing/ProductFeatures'
import VideoSection from './landing/VideoSection'
import ExploreSection from './landing/ExploreSection'
import PopularPlacesSection from './landing/PopularPlacesSection'
import FinalCTA from './landing/FinalCTA'
import FAQ from './landing/FAQ'
import BTSSection from './landing/BTSSection'
import Footer from './landing/Footer'
import TutorialVideo from './landing/TutorialVideo'

function LandingPage() {
  // Matches the static <title>/meta robots already baked into
  // index.html for first paint & crawlers — this just restores them if
  // the person navigates back to "/" client-side after visiting /map.
  useSeo({
    title: 'Maps By FUTA – Campus Map & Navigation for Federal University of Technology, Akure',
    robots: 'index, follow',
  });

  return (
    <>
      {/* Slice 11 QA fix: .hero-fade/.reveal/.reveal-scale (landing.css)
          default to opacity:0 and only reach their visible end state via
          a JS-driven IntersectionObserver (useReveal in landingHooks.js)
          adding a .visible class. That's fine when JS runs, but with
          scripting off entirely (not just prefers-reduced-motion — real
          no-JS browsing) nothing ever adds .visible and every section
          stays invisible forever, which is exactly what Slice 10's own
          acceptance check called out as unacceptable. This forces the
          end state when scripting is disabled, without touching the
          normal JS-enabled animation path at all. */}
      <noscript>
        <style>{`.hero-fade, .reveal, .reveal-scale { opacity: 1 !important; transform: none !important; }`}</style>
      </noscript>
      <Nav />
      <Hero />
      <TrustBar />
      {/* Full-section launch countdown. Placed after TrustBar rather
          than directly under Hero: Hero's floating map-preview card
          intentionally bleeds past Hero's own bottom edge, and putting
          the countdown immediately after Hero put its big numbers
          right underneath that overlap. TrustBar's thin strip gives
          the preview card room to fully clear before this section
          starts, so nothing collides. See launchConfig.js for the
          LAUNCH_DATE constant if the date needs tweaking later. */}
      {/* <LaunchCountdown /> */}
      <CampusTransformSection />
      <ProductFeatures />
      <VideoSection />
      <ExploreSection />
      <PopularPlacesSection />
      <FinalCTA />
      {/* <BTSSection /> */}
        <FAQ />
      <Footer />
      <TutorialVideo />
    </>
  )
}

export default LandingPage
